# Deep-Learning-nanodegree
The course is from [nanodegree of Udacity](https://www.udacity.com/nanodegree).
The course provides multiple algorithms of deep learning with hands-on projects.

The course is composed of 6 sections including 5 projects.

# 1. Introduction
# 2. Neural Networks
## Project 1. Predicting Bike Sharing Data.
## Sentiment Analysis

# 3. Convolutional Networks
## Project 2. CNN Project: Dog Breed Classifier.

# 4. Recurrent Networks
## Project 3.

# 5. Generative Adversarial Networks
## Project 4. Face Generation

# 6. Deep Reinforcement Learning
## Project 5. Teach a Quadcopter How to Fly!
