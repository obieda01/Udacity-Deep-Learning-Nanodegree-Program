# Lesson 5: Embedding and word2vec
Word embeddings in particular are interesting because the networks are able to learn semantic relationships between words.
