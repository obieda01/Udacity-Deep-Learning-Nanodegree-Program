# 1 Recurrent Networks
# 2 Long Short-term memory Networks(LSTM)
# 3 Implmentation of RNN and LSTM
# 4 Hyperparameters
# 5 Embeddings and Word2vec
# 6 Sentimen Prediction RNN
# 7 Project: Generate TV scripts
