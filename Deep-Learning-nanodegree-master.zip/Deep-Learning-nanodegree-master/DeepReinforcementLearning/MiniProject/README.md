# Mini Project: Solve OpenAI Gym's Taxi-v2 Task
[OpenAI Gym's Taxi-v2 Task](https://gym.openai.com/envs/Taxi-v2/)
I used Q-learning to have the total rewards.

## Evaluate your Performance
OpenAI Gym defines "solving" this task as getting average return of 9.7 over 100 consecutive trials.

While this mini project is ungraded, we recommend that you try to attain an average return of at least 9.1 over 100 consecutive trials (best_avg_reward > 9.1).
